#!/bin/sh
# QuecTool on-modem installer (RO /lib compatible).
# Run from the unpacked tarball directory:  sh install.sh
#
# Layout produced:
#   /usrdata/quectool/quectool          binary
#   /usrdata/quectool/quectool.yaml     config (preserved across upgrades)
#   /usrdata/quectool/bin/{at,qtrestart,qtreboot,qtstatus}  CLI helpers
# Tarball layout mirrors this: bin/ holds helpers; root has install + unit + yaml.
#   /usrdata/quectool/server.{crt,key} TLS leaf (auto-generated on first boot)
#   /usrdata/quectool/ca.{pem,key}     local CA when ca_* paths set in YAML
#   /lib/systemd/system/quectool.service          (when /lib is writable)
#   /etc/systemd/system/quectool.service          (fallback when /lib is RO)
#   multi-user.target.wants/quectool.service      (enable symlink)
#   /usrdata/etc/init.post_boot.sh     (quectool block only — when /lib is RO)
#
# Root (/) is often read-only on Quectel firmware. This script remounts rw
# only for the unit install window, then remounts ro. Persistent state lives
# under /usrdata (writable).
#
# Idempotent. Safe to re-run for upgrades.

set -e

if [ "$(id -u)" != "0" ]; then
    echo "install.sh: must run as root" >&2
    exit 1
fi

HERE=$(cd "$(dirname "$0")" && pwd)
INSTALL_DIR=/usrdata/quectool
POST_BOOT=/usrdata/etc/init.post_boot.sh
# Markers so we only own our block inside post_boot (other vendors may share the file).
BEGIN_MARK="# BEGIN quectool"
END_MARK="# END quectool"

for f in quectool quectool.yaml quectool.service uninstall.sh; do
    if [ ! -f "$HERE/$f" ]; then
        echo "install.sh: missing $f next to installer" >&2
        exit 1
    fi
done

remount() {
    mount -o "remount,$1" / 2>/dev/null || true
}

# Detect /lib writability AFTER remount rw (see below). Pre-remount touch
# always fails on RO root and wrongly forces /etc unit path.
detect_unit_paths() {
    mkdir -p /lib/systemd/system /etc/systemd/system 2>/dev/null || true
    LIB_TEST="/lib/systemd/system/.write_test_$$"
    if touch "$LIB_TEST" 2>/dev/null; then
        rm -f "$LIB_TEST"
        UNIT_DST=/lib/systemd/system/quectool.service
        WANTS_DIR=/lib/systemd/system/multi-user.target.wants
        USE_FALLBACK=false
    else
        echo "==> /lib still read-only after remount, using /etc/systemd/system"
        UNIT_DST=/etc/systemd/system/quectool.service
        WANTS_DIR=/etc/systemd/system/multi-user.target.wants
        USE_FALLBACK=true
    fi
}

# Insert or replace only the quectool-marked block in post_boot.
# Never truncates unrelated content that may already live in that file.
write_post_boot_block() {
    mkdir -p "$(dirname "$POST_BOOT")"
    block=$(cat <<EOF
$BEGIN_MARK
# Auto-start QuecTool after boot (RO-root / flaky systemd cgroup fallback).
(
  sleep 8
  systemctl daemon-reload 2>/dev/null || true
  if [ -f /usrdata/quectool/.direct-start ]; then
    # OpenLinux images without a usable systemd cgroup hierarchy: keep the
    # service disabled and start QuecTool directly instead of retrying 219.
    systemctl stop quectool.service 2>/dev/null || true
    systemctl disable quectool.service 2>/dev/null || true
    pkill -9 -x quectool 2>/dev/null || true
    nohup /usrdata/quectool/quectool server -c /usrdata/quectool/quectool.yaml \
      >>/usrdata/quectool/quectool.log 2>&1 &
    echo $! >/usrdata/quectool/quectool.pid
  else
    systemctl enable quectool.service 2>/dev/null || true
    systemctl start quectool.service 2>/dev/null || true
  fi
  if [ ! -f /usrdata/quectool/.direct-start ]; then
    # Give Type=simple unit time to bind :443; if still down, direct-start.
    sleep 12
    if ! systemctl is-active --quiet quectool.service 2>/dev/null; then
      pkill -9 -x quectool 2>/dev/null || true
      # Bound log before append (flash-friendly; no journald on direct-start).
      _L=/usrdata/quectool/quectool.log
    if [ -f "\$_L" ]; then
      _sz=\$(wc -c <"\$_L" 2>/dev/null || echo 0)
      case "\$_sz" in ''|*[!0-9]*) _sz=0 ;; esac
      if [ "\$_sz" -gt 2097152 ]; then
        tail -n 3000 "\$_L" >"\$_L.tmp" 2>/dev/null && mv "\$_L.tmp" "\$_L" || : >"\$_L"
      fi
    fi
    nohup /usrdata/quectool/quectool server -c /usrdata/quectool/quectool.yaml \\
      >>\$_L 2>&1 &
    echo \$! >/usrdata/quectool/quectool.pid
    fi
  fi
) &
$END_MARK
EOF
)
    if [ -f "$POST_BOOT" ] && grep -q "$BEGIN_MARK" "$POST_BOOT" 2>/dev/null; then
        # Replace existing marked block (awk keeps everything outside markers).
        tmp="${POST_BOOT}.new.$$"
        awk -v b="$BEGIN_MARK" -v e="$END_MARK" '
            $0 == b { skip=1; next }
            $0 == e { skip=0; next }
            !skip { print }
        ' "$POST_BOOT" > "$tmp"
        printf '%s\n' "$block" >> "$tmp"
        mv -f "$tmp" "$POST_BOOT"
    elif [ -f "$POST_BOOT" ]; then
        # Append our block; preserve existing script body.
        # Ensure file ends with a newline before appending.
        [ -s "$POST_BOOT" ] && [ "$(tail -c1 "$POST_BOOT" | wc -l)" -eq 0 ] && echo >> "$POST_BOOT"
        printf '%s\n' "$block" >> "$POST_BOOT"
    else
        # New file: shebang + our block only.
        {
            echo "#!/bin/sh"
            printf '%s\n' "$block"
        } > "$POST_BOOT"
    fi
    chmod 0755 "$POST_BOOT"
}

echo "==> remounting / read-write"
remount rw

# Now that / is (hopefully) rw, pick unit install path.
detect_unit_paths
echo "==> unit path: $UNIT_DST (fallback=$USE_FALLBACK)"

# Aggressively purge ALL legacy boot hooks before installing. Previous
# install.sh versions dropped scripts in multiple places; having both a
# /etc/init.d/quectool AND quectool.service with the same name makes
# systemd route `enable` through sysv-install, which fails without
# update-rc.d on this firmware → enable silently aborts → never starts.
echo "==> purging legacy boot hooks"
rm -f /etc/init.d/quectool /etc/initscripts/quectool /etc/initscripts/start_quectool 2>/dev/null
rm -f /etc/rcS.d/S99quectool /etc/rc5.d/S99quectool 2>/dev/null
rm -f /etc/rc2.d/S99quectool /etc/rc3.d/S99quectool /etc/rc4.d/S99quectool 2>/dev/null
rm -f /etc/rc1.d/K01quectool 2>/dev/null

# Stop the running service FIRST so :443 and /dev/smd* are free before we
# replace the binary and start again. Reinstall used to leave a half-dead
# process holding the port → new binary Fatal on Listen → power-cycle only fix.
echo "==> stopping any running quectool (free :443 / AT port)"
stop_quectool() {
    # Prevent Restart=on-failure from respawning mid-install (causes EBUSY
    # on binary replace and fights for :443).
    systemctl stop quectool.service 2>/dev/null || true
    systemctl reset-failed quectool.service 2>/dev/null || true
    # TERM then KILL; wait until no process remains.
    pkill -x quectool 2>/dev/null || true
    i=0
    while [ "$i" -lt 20 ]; do
        if ! pidof quectool >/dev/null 2>&1; then
            # also check ps pattern (busybox without pidof)
            if ! ps 2>/dev/null | grep -v grep | grep -q '[q]uectool'; then
                break
            fi
        fi
        i=$((i+1))
        sleep 1
        # escalate after a few seconds
        if [ "$i" -eq 3 ] || [ "$i" -eq 8 ] || [ "$i" -eq 15 ]; then
            pkill -9 -x quectool 2>/dev/null || true
            killall -9 quectool 2>/dev/null || true
            # Direct-start pidfile
            if [ -f "$INSTALL_DIR/quectool.pid" ]; then
                kill -9 "$(cat "$INSTALL_DIR/quectool.pid" 2>/dev/null)" 2>/dev/null || true
            fi
        fi
    done
    pkill -9 -x quectool 2>/dev/null || true
    killall -9 quectool 2>/dev/null || true
    rm -f "$INSTALL_DIR/quectool.pid" 2>/dev/null || true
    # Give kernel a beat to release TCP TIME_WAIT / exclusive smd open / text maps.
    sleep 2
}

# Jail bind-mounts the live binary at jail/qt/quectool (and yaml). Replacing
# /usrdata/quectool/quectool with mv/rename while that bind exists →
# "Device or resource busy" on BusyBox/OpenLinux. Detach BEFORE install.
umount_jail_binds() {
    _j="$INSTALL_DIR/jail"
    [ -d "$_j" ] || return 0
    echo "==> detaching console jail binds (free binary for replace)"
    if [ -r /proc/self/mountinfo ]; then
        awk -v root="$_j" '
            $5 == root || index($5, root "/") == 1 { print length($5), $5 }
        ' /proc/self/mountinfo | sort -rn | while read -r _ mp; do
            [ "$mp" = "$_j" ] && continue
            umount -l "$mp" 2>/dev/null || umount "$mp" 2>/dev/null || true
        done
    fi
    # Explicit hot paths (file binds + trees) — order deep-first.
    for d in \
        qt/quectool qt/quectool.yaml \
        dev/pts dev/ptmx dev/smd11 dev/smd7 dev/smd8 dev/smd9 \
        dev/ttyUSB0 dev/ttyUSB1 dev/ttyUSB2 dev/ttyUSB3 \
        dev/console dev/tty0 \
        usr lib lib64 bin sbin opt etc dev proc sys tmp; do
        umount -l "$_j/$d" 2>/dev/null || umount "$_j/$d" 2>/dev/null || true
    done
    sleep 1
}

install_binary() {
    # Write sibling, then replace path. Fallbacks for BusyBox EBUSY.
    _src="$HERE/quectool"
    _dst="$INSTALL_DIR/quectool"
    _new="$INSTALL_DIR/quectool.new"
    _bak="$INSTALL_DIR/quectool.prev"
    rm -f "$_new" 2>/dev/null || true
    cp "$_src" "$_new"
    chmod 0755 "$_new"

    # 1) Preferred: atomic rename over destination.
    if mv -f "$_new" "$_dst" 2>/dev/null; then
        return 0
    fi
    echo "    mv replace busy — retry after re-umount / hard stop…"
    stop_quectool
    umount_jail_binds
    if mv -f "$_new" "$_dst" 2>/dev/null; then
        return 0
    fi

    # 2) Move old aside, then move new into place (old may stay if ETXTBSY unlink).
    rm -f "$_bak" 2>/dev/null || true
    if mv -f "$_dst" "$_bak" 2>/dev/null; then
        if mv -f "$_new" "$_dst" 2>/dev/null; then
            rm -f "$_bak" 2>/dev/null || true
            return 0
        fi
        # roll back name if possible
        mv -f "$_bak" "$_dst" 2>/dev/null || true
    fi

    # 3) Last resort: copy over destination (works if nothing maps the inode).
    if cp -f "$_new" "$_dst" 2>/dev/null; then
        chmod 0755 "$_dst"
        rm -f "$_new" 2>/dev/null || true
        return 0
    fi

    echo "install.sh: cannot replace $_dst (Device or resource busy)" >&2
    echo "  Try: systemctl stop quectool; pkill -9 quectool; umount jail binds; re-run install" >&2
    echo "  Or:  ls -l $_dst; cat /proc/mounts | grep quectool" >&2
    ls -l "$_dst" "$_new" 2>/dev/null >&2 || true
    return 1
}

stop_quectool
umount_jail_binds

echo "==> installing binary to $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
# Plain `cp` onto a running ELF → ETXTBSY. File bind of the binary into
# jail/qt/quectool → mv rename EBUSY. Stop + umount first, then replace.
install_binary

# CLI helpers live under $INSTALL_DIR/bin/ so the install root stays tidy:
#   bin/at  bin/qtrestart  bin/qtreboot  bin/qtstatus  bin/sendcommand -> at
# Core files stay at $INSTALL_DIR/: quectool, quectool.yaml, certs, logs, jail/
BIN_DIR="$INSTALL_DIR/bin"
mkdir -p "$BIN_DIR"
# Remove legacy helpers that used to sit next to the binary (pre-v1.6.33).
rm -f "$INSTALL_DIR/at" "$INSTALL_DIR/sendcommand" \
      "$INSTALL_DIR/qtrestart" "$INSTALL_DIR/qtreboot" "$INSTALL_DIR/qtstatus" 2>/dev/null || true

# Helpers ship in tarball as bin/* (preferred) or flat next to install.sh (legacy).
TOOLS_SRC="$HERE/bin"
[ -f "$TOOLS_SRC/at" ] || TOOLS_SRC="$HERE"

if [ -f "$TOOLS_SRC/at" ]; then
    echo "==> installing CLI helpers under $BIN_DIR (from ${TOOLS_SRC#$HERE/})"
    cp "$TOOLS_SRC/at" "$BIN_DIR/at"
    chmod 0755 "$BIN_DIR/at"
    if [ -f "$TOOLS_SRC/qtrestart" ]; then
        cp "$TOOLS_SRC/qtrestart" "$BIN_DIR/qtrestart"
        chmod 0755 "$BIN_DIR/qtrestart"
    fi
    if [ -f "$TOOLS_SRC/qtreboot" ]; then
        cp "$TOOLS_SRC/qtreboot" "$BIN_DIR/qtreboot"
        chmod 0755 "$BIN_DIR/qtreboot"
    fi
    if [ -f "$TOOLS_SRC/qtstatus" ]; then
        cp "$TOOLS_SRC/qtstatus" "$BIN_DIR/qtstatus"
        chmod 0755 "$BIN_DIR/qtstatus"
    fi
    # Compat alias
    if [ -f "$TOOLS_SRC/sendcommand" ]; then
        cp "$TOOLS_SRC/sendcommand" "$BIN_DIR/sendcommand"
        chmod 0755 "$BIN_DIR/sendcommand"
    else
        ln -sf at "$BIN_DIR/sendcommand" 2>/dev/null || cp "$BIN_DIR/at" "$BIN_DIR/sendcommand"
    fi
    # Optional PATH exposure (first existing/writable dir wins).
    for bindir in /usrdata/root/bin /opt/bin /usrdata/bin; do
        if [ -d "$bindir" ] || mkdir -p "$bindir" 2>/dev/null; then
            ln -sf "$BIN_DIR/at" "$bindir/at" 2>/dev/null || true
            ln -sf "$BIN_DIR/at" "$bindir/sendcommand" 2>/dev/null || true
            ln -sf "$BIN_DIR/qtrestart" "$bindir/qtrestart" 2>/dev/null || true
            ln -sf "$BIN_DIR/qtreboot" "$bindir/qtreboot" 2>/dev/null || true
            ln -sf "$BIN_DIR/qtstatus" "$bindir/qtstatus" 2>/dev/null || true
            ln -sf "$INSTALL_DIR/quectool" "$bindir/quectool" 2>/dev/null || true
            break
        fi
    done
fi

# First-install only: drop the default config. On upgrades, leave the
# operator's edits alone — write the new defaults next to it for diffing.
if [ -f "$INSTALL_DIR/quectool.yaml" ]; then
    echo "==> preserving existing $INSTALL_DIR/quectool.yaml"
    cp "$HERE/quectool.yaml" "$INSTALL_DIR/quectool.yaml.new"
    echo "    (new defaults written to quectool.yaml.new for review)"
    # Critical migration: bash -l inside the console jail sources host
    # /etc/profile and often exits immediately on OpenLinux → web console
    # reconnect loop. Strip -l / --login from terminal + ssh shell args.
    if grep -E 'args:.*\[.*-l|shell_args:.*\[.*-l|args:.*--login|shell_args:.*--login' \
        "$INSTALL_DIR/quectool.yaml" >/dev/null 2>&1; then
        echo "==> migrating quectool.yaml: drop login-shell -l (console fix)"
        # Backup once.
        cp -n "$INSTALL_DIR/quectool.yaml" "$INSTALL_DIR/quectool.yaml.bak" 2>/dev/null || \
            cp "$INSTALL_DIR/quectool.yaml" "$INSTALL_DIR/quectool.yaml.bak.$$"
        # Replace common list forms; keep other keys untouched.
        sed -i \
            -e 's/args: \["-i", "-l"\]/args: ["--rcfile", "\/home\/admin\/.bashrc", "-i"]/' \
            -e 's/args: \["-l", "-i"\]/args: ["--rcfile", "\/home\/admin\/.bashrc", "-i"]/' \
            -e 's/shell_args: \["-i", "-l"\]/shell_args: ["--rcfile", "\/home\/admin\/.bashrc", "-i"]/' \
            -e 's/shell_args: \["-l", "-i"\]/shell_args: ["--rcfile", "\/home\/admin\/.bashrc", "-i"]/' \
            -e 's/args: \["-i", "--login"\]/args: ["--rcfile", "\/home\/admin\/.bashrc", "-i"]/' \
            -e 's/shell_args: \["-i", "--login"\]/shell_args: ["--rcfile", "\/home\/admin\/.bashrc", "-i"]/' \
            "$INSTALL_DIR/quectool.yaml" 2>/dev/null || true
        echo "    (backup: quectool.yaml.bak*)"
    fi
    # USSD on OpenLinux needs smd7: empty port_alt: overrides Go default.
    if grep -E '^[[:space:]]*port_alt:[[:space:]]*$' "$INSTALL_DIR/quectool.yaml" >/dev/null 2>&1 \
       && [ -e /dev/smd7 ]; then
        echo "==> migrating quectool.yaml: modem.port_alt=/dev/smd7 (USSD +CUSD)"
        cp -n "$INSTALL_DIR/quectool.yaml" "$INSTALL_DIR/quectool.yaml.bak" 2>/dev/null || true
        sed -i 's/^[[:space:]]*port_alt:[[:space:]]*$/  port_alt: \/dev\/smd7/' \
            "$INSTALL_DIR/quectool.yaml" 2>/dev/null || true
    fi
else
    echo "==> writing default $INSTALL_DIR/quectool.yaml"
    cp "$HERE/quectool.yaml" "$INSTALL_DIR/quectool.yaml"
fi

# Sanity: binary must be executable ELF-ish and report a version.
if [ ! -x "$INSTALL_DIR/quectool" ]; then
    echo "install.sh: $INSTALL_DIR/quectool is not executable" >&2
    exit 1
fi

echo "==> installing uninstaller for later"
cp "$HERE/uninstall.sh" "$INSTALL_DIR/uninstall.sh"
chmod 0755 "$INSTALL_DIR/uninstall.sh"

# Remove legacy menu-style console scripts (v1.6.5).
if [ -d "$INSTALL_DIR/console" ]; then
    echo "==> removing legacy $INSTALL_DIR/console"
    rm -rf "$INSTALL_DIR/console"
fi
# Remove v1.6.10 HOME-only path (replaced by chroot jail/).
rm -rf "$INSTALL_DIR/home" 2>/dev/null || true

# Jail uses RO bind links under jail/. On upgrade, leave mounts alone —
# the binary Ensure() is idempotent. Only mkdir empty mountpoints here.
# NEVER copy host /bin into jail (zero-copy binds only).
mkdir -p "$INSTALL_DIR/jail/home/admin" "$INSTALL_DIR/jail/tmp" "$INSTALL_DIR/jail/qt"
# Seed /qt/quectool.yaml so jail helpers work even before the first
# consolejail.Ensure() refresh (qtrestart used to fail with missing yaml).
if [ -f "$INSTALL_DIR/quectool.yaml" ]; then
    cp -f "$INSTALL_DIR/quectool.yaml" "$INSTALL_DIR/jail/qt/quectool.yaml" 2>/dev/null || true
    chmod 0644 "$INSTALL_DIR/jail/qt/quectool.yaml" 2>/dev/null || true
fi

# Install systemd unit. Prefer /lib (survives boot on RG50xQ). Always also
# drop a copy under /etc when /lib works, then remove /etc wants to avoid
# dual-enable / sysv-install fights. If /lib is still RO, use /etc only.
echo "==> installing systemd unit to $UNIT_DST"
mkdir -p "$(dirname "$UNIT_DST")" "$WANTS_DIR" 2>/dev/null || true
cp "$HERE/quectool.service" "$UNIT_DST"
# Also keep a copy next to the binary for recovery / manual enable.
cp "$HERE/quectool.service" "$INSTALL_DIR/quectool.service"

if [ "$USE_FALLBACK" = false ]; then
    # Canonical boot path.
    mkdir -p /lib/systemd/system/multi-user.target.wants
    ln -sf /lib/systemd/system/quectool.service \
        /lib/systemd/system/multi-user.target.wants/quectool.service
    # Drop /etc duplicate unit+wants that confuse enable on this firmware.
    rm -f /etc/systemd/system/quectool.service \
          /etc/systemd/system/multi-user.target.wants/quectool.service 2>/dev/null || true
else
    mkdir -p /etc/systemd/system/multi-user.target.wants
    ln -sf /etc/systemd/system/quectool.service \
        /etc/systemd/system/multi-user.target.wants/quectool.service
fi

# --- Boot persistence ---
# Always ensure a post_boot safety net: OpenLinux often loses /etc units on
# reboot and/or fails systemctl with 219/CGROUP. Block is idempotent.
echo "==> ensuring quectool block in $POST_BOOT"
write_post_boot_block

echo "==> reloading daemon & starting service"
systemctl daemon-reload 2>/dev/null || true
systemctl enable quectool.service 2>/dev/null || true

# Already stopped / umounted before binary replace; re-assert before start.
stop_quectool
umount_jail_binds

quectool_listening() {
    # Best-effort: is something accepting on the configured UI port?
    _port=$(awk '/^[[:space:]]*port:/ { gsub(/"/, "", $2); print $2; exit }' "$INSTALL_DIR/quectool.yaml" 2>/dev/null || echo 443)
    [ -n "$_port" ] || _port=443
    if command -v ss >/dev/null 2>&1; then
        ss -lnt 2>/dev/null | grep -q ":$_port " && return 0
    fi
    if command -v netstat >/dev/null 2>&1; then
        netstat -lnt 2>/dev/null | grep -q ":$_port " && return 0
    fi
    # BusyBox: try /proc/net/tcp hex port
    _hex=$(printf '%04X' "$_port" 2>/dev/null) || return 1
    [ -n "$_hex" ] || return 1
    if [ -r /proc/net/tcp ]; then
        awk -v p=":$_hex" 'NR>1 { split($2,a,":"); if (toupper(a[2])==toupper(substr(p,2))) exit 0 } END{exit 1}' /proc/net/tcp 2>/dev/null && return 0
    fi
    return 1
}

quectool_alive() {
    # True if systemd says active OR our pidfile process is alive OR any
    # quectool server process is running.
    if systemctl is-active --quiet quectool.service 2>/dev/null; then
        return 0
    fi
    if [ -f "$INSTALL_DIR/quectool.pid" ]; then
        if kill -0 "$(cat "$INSTALL_DIR/quectool.pid" 2>/dev/null)" 2>/dev/null; then
            return 0
        fi
    fi
    if pidof quectool >/dev/null 2>&1; then
        return 0
    fi
    # Busybox/toybox may lack pidof — fall back to ps.
    if ps 2>/dev/null | grep -v grep | grep -q '[q]uectool server'; then
        return 0
    fi
    return 1
}

# Wait until UI port accepts connections (or timeout). Returns 0 on listen.
wait_for_listen() {
    _max=${1:-30}
    i=0
    while [ "$i" -lt "$_max" ]; do
        if quectool_listening; then
            return 0
        fi
        # Process died mid-boot → fail fast
        if ! quectool_alive; then
            return 1
        fi
        i=$((i+1))
        sleep 1
    done
    quectool_listening
}

start_via_systemd() {
    # A previous boot/install proved that this image cannot create service
    # cgroups. Do not retry the known-broken systemd path.
    if [ -f "$INSTALL_DIR/.direct-start" ]; then
        return 1
    fi
    systemctl reset-failed quectool.service 2>/dev/null || true
    systemctl start quectool.service 2>/dev/null || return 1
    # Type=simple reports active before :443 is bound — wait for real listen.
    if wait_for_listen 25; then
        return 0
    fi
    # 219/CGROUP or crash-before-listen
    systemctl is-failed --quiet quectool.service 2>/dev/null && return 1
    # Still alive but not listening → treat as failure so direct start can run
    return 1
}

# Direct start bypasses broken cgroup setup (status=219/CGROUP on some builds).
start_direct() {
    echo "==> starting binary directly (bypass systemd cgroup issues)"
    # Persist the fallback: otherwise post_boot/systemd retries the same
    # broken cgroup unit on every reboot and logs 219/CGROUP forever.
    : >"$INSTALL_DIR/.direct-start"
    # Prevent systemd Restart=on-failure from fighting us for :443.
    systemctl stop quectool.service 2>/dev/null || true
    systemctl reset-failed quectool.service 2>/dev/null || true
    # Mask briefly? not available everywhere — just kill leftovers hard.
    stop_quectool
    rm -f "$INSTALL_DIR/quectool.pid"
    # Keep last boot context but bound size (was full truncate — lose history).
    _LOG="$INSTALL_DIR/quectool.log"
    if [ -f "$_LOG" ]; then
        _sz=$(wc -c <"$_LOG" 2>/dev/null || echo 0)
        case "$_sz" in ''|*[!0-9]*) _sz=0 ;; esac
        if [ "$_sz" -gt 2097152 ]; then
            tail -n 3000 "$_LOG" >"$_LOG.tmp" 2>/dev/null && mv "$_LOG.tmp" "$_LOG" || : >"$_LOG"
        fi
        # Mark install boundary for tail debugging.
        echo "==== install direct-start $(date 2>/dev/null || true) ====" >>"$_LOG"
    else
        : >"$_LOG" 2>/dev/null || true
    fi
    nohup "$INSTALL_DIR/quectool" server -c "$INSTALL_DIR/quectool.yaml" \
        >>"$_LOG" 2>&1 &
    echo $! >"$INSTALL_DIR/quectool.pid"
    if wait_for_listen 30; then
        echo "==> quectool running directly (pid $(cat "$INSTALL_DIR/quectool.pid" 2>/dev/null)) — UI listening"
        return 0
    fi
    echo "ERROR: direct start also failed; see $INSTALL_DIR/quectool.log" >&2
    tail -50 "$INSTALL_DIR/quectool.log" 2>/dev/null >&2 || true
    return 1
}

echo "==> starting quectool"
# Prefer systemd; if unit is active-but-not-listening or 219, fall back to direct.
if start_via_systemd; then
    echo "==> quectool is active (systemd) — UI listening"
elif start_direct; then
    :
else
    echo "ERROR: quectool is NOT listening after install" >&2
    echo "---- systemctl status ----" >&2
    systemctl status quectool.service --no-pager -l 2>&1 | tail -40 >&2 || true
    echo "---- quectool.log (tail) ----" >&2
    tail -50 "$INSTALL_DIR/quectool.log" 2>/dev/null >&2 || true
    echo "---- manual try ----" >&2
    echo "  $INSTALL_DIR/quectool server -c $INSTALL_DIR/quectool.yaml" >&2
fi

echo "==> remounting / read-only"
remount ro

# `--version` now prints just "v1.1.47..." (VersionTemplate override in root.go).
VERSION=$("$INSTALL_DIR/quectool" --version 2>/dev/null || echo unknown)
PORT=$(awk '/^[[:space:]]*port:/ { gsub(/"/, "", $2); print $2; exit }' "$INSTALL_DIR/quectool.yaml" 2>/dev/null || echo 443)
TLS=$(awk '/^[[:space:]]*tls:/ { print $2; exit }' "$INSTALL_DIR/quectool.yaml" 2>/dev/null || echo true)
SCHEME=https
if [ "$TLS" = "false" ]; then SCHEME=http; fi

# Detect the modem's LAN IP to print a clickable URL (best-effort).
# Try hostname -I, then fall back to scanning bridge0/eth0/rndis0.
detect_ip() {
    # Note: no `local` — BusyBox ash on some Quectel images rejects it.
    if command -v hostname >/dev/null 2>&1; then
        _ips=$(hostname -I 2>/dev/null)
        if [ -n "$_ips" ]; then
            echo "$_ips" | awk '{print $1}'
            return
        fi
    fi
    for iface in bridge0 eth0 rndis0 usb0; do
        if command -v ip >/dev/null 2>&1; then
            _addr=$(ip -f inet -o addr show "$iface" 2>/dev/null | awk '{split($4,a,"/"); print a[1]}')
            if [ -n "$_addr" ]; then echo "$_addr"; return; fi
        fi
        if command -v ifconfig >/dev/null 2>&1; then
            _addr2=$(ifconfig "$iface" 2>/dev/null | awk '/inet /{sub(/addr:/,"",$2); print $2; exit}')
            if [ -n "$_addr2" ]; then echo "$_addr2"; return; fi
        fi
    done
}
DETECTED_IP=$(detect_ip)
URL_HOST="<modem-ip>"
if [ -n "$DETECTED_IP" ]; then URL_HOST="$DETECTED_IP"; fi

# Suppress :PORT when it's the scheme default (443/https, 80/http) so the
# printed URL stays clean:  https://192.168.225.1  instead of  ...:443
URL="$SCHEME://$URL_HOST"
if [ "$PORT" != "443" ] && [ "$PORT" != "80" ]; then
    URL="$URL:$PORT"
fi

RUN_STATE="unknown"
if systemctl is-active --quiet quectool.service 2>/dev/null; then
    RUN_STATE="systemd active"
elif quectool_alive; then
    RUN_STATE="running (direct/pid)"
else
    RUN_STATE="NOT RUNNING"
    echo "==> last log lines ($INSTALL_DIR/quectool.log):" >&2
    tail -30 "$INSTALL_DIR/quectool.log" 2>/dev/null >&2 || true
fi

cat <<EOF

QuecTool $VERSION installed.
  config:  $INSTALL_DIR/quectool.yaml
  unit:    $UNIT_DST
  status:  $RUN_STATE
  url:     $URL

Logs:     tail -f $INSTALL_DIR/quectool.log
          journalctl -u quectool -f
Restart:  systemctl restart quectool
          # or: kill \$(cat $INSTALL_DIR/quectool.pid); $INSTALL_DIR/quectool server -c $INSTALL_DIR/quectool.yaml &
AT test:  at ATI
          # or: $INSTALL_DIR/bin/at ATI

If web Console reconnect-loops: ensure terminal args are NOT -l
  grep -n terminal -A3 $INSTALL_DIR/quectool.yaml
  # should look like: args: ["--rcfile", "/home/admin/.bashrc", "-i"]
EOF
