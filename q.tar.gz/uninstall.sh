#!/bin/sh
# QuecTool on-modem uninstaller (RO /lib compatible).
#
#   sh uninstall.sh           # stop + disable, leave /usrdata/quectool intact
#   sh uninstall.sh --purge   # also delete /usrdata/quectool entirely
#
# Run on the modem as root.
#
# Mirrors install.sh:
#   - remount / rw only while touching unit files under /lib or /etc
#   - remove unit + wants from BOTH /lib and /etc (install may have used either)
#   - strip only the marked quectool block from /usrdata/etc/init.post_boot.sh
#     (never delete the whole file — other software may share it)

set -e

if [ "$(id -u)" != "0" ]; then
    echo "uninstall.sh: must run as root" >&2
    exit 1
fi

PURGE=0
if [ "$1" = "--purge" ]; then
    PURGE=1
fi

INSTALL_DIR=/usrdata/quectool
POST_BOOT=/usrdata/etc/init.post_boot.sh
BEGIN_MARK="# BEGIN quectool"
END_MARK="# END quectool"

remount() {
    mount -o "remount,$1" / 2>/dev/null || true
}

# Detach console jail bind mounts under $INSTALL_DIR/jail.
# CRITICAL: never rm -rf the jail (or INSTALL_DIR) while /bin /lib /usr /etc
# are still bind-mounted there — that can delete the real host trees and
# brick the device (boot loop / no shell).
umount_console_jail() {
    jail="$INSTALL_DIR/jail"
    [ -d "$jail" ] || return 0
    echo "==> unmounting console jail under $jail (if any)"
    # Deepest mountpoints first (from kernel table), then known leaves.
    if [ -r /proc/self/mountinfo ]; then
        awk -v root="$jail" '
            $5 == root || index($5, root "/") == 1 { print length($5), $5 }
        ' /proc/self/mountinfo | sort -rn | while read -r _ mp; do
            # Never lazy-umount the jail directory itself if it were a mount;
            # only children. root alone is not a bind of host /.
            [ "$mp" = "$jail" ] && continue
            umount -l "$mp" 2>/dev/null || umount "$mp" 2>/dev/null || true
        done
    elif [ -r /proc/mounts ]; then
        awk -v root="$jail" '
            $2 == root || index($2, root "/") == 1 { print length($2), $2 }
        ' /proc/mounts | sort -rn | while read -r _ mp; do
            [ "$mp" = "$jail" ] && continue
            umount -l "$mp" 2>/dev/null || umount "$mp" 2>/dev/null || true
        done
    fi
    # Known destinations even if mountinfo parse missed them.
    for d in dev/pts dev/smd11 dev/smd7 dev/smd8 dev/smd9 \
             dev/ttyUSB0 dev/ttyUSB1 dev/ttyUSB2 dev/ttyUSB3 \
             qt/quectool qt/quectool.yaml \
             usr/lib usr/bin usr lib64 lib bin sbin opt etc dev proc sys tmp; do
        umount -l "$jail/$d" 2>/dev/null || umount "$jail/$d" 2>/dev/null || true
    done
    # Safety: refuse purge if anything under jail is still a mountpoint.
    if [ -r /proc/self/mountinfo ] && awk -v root="$jail" '
        $5 == root || index($5, root "/") == 1 { found=1; exit }
        END { exit !found }
    ' /proc/self/mountinfo; then
        echo "uninstall.sh: WARNING: mounts still present under $jail" >&2
        echo "    aborting purge of jail to protect host filesystem" >&2
        return 1
    fi
    return 0
}

# Remove only the marked quectool section from post_boot.
# If the file becomes empty / shebang-only, leave it (do not rm the file).
# Also strips a legacy whole-file pattern from older installers that
# overwrote post_boot with only quectool enable/start lines (no markers).
strip_post_boot_quectool() {
    [ -f "$POST_BOOT" ] || return 0

    tmp="${POST_BOOT}.new.$$"
    if grep -q "$BEGIN_MARK" "$POST_BOOT" 2>/dev/null; then
        awk -v b="$BEGIN_MARK" -v e="$END_MARK" '
            $0 == b { skip=1; next }
            $0 == e { skip=0; next }
            !skip { print }
        ' "$POST_BOOT" > "$tmp"
        mv -f "$tmp" "$POST_BOOT"
        chmod 0755 "$POST_BOOT" 2>/dev/null || true
        echo "    removed quectool block from $POST_BOOT"
        return 0
    fi

    # Legacy: older install.sh wrote the entire file as only our enable/start.
    # Only strip if the file looks like that exclusive content (safe heuristic).
    if grep -q 'systemctl enable quectool' "$POST_BOOT" 2>/dev/null \
       && grep -q 'systemctl start quectool' "$POST_BOOT" 2>/dev/null; then
        # Drop lines that clearly belong to the old exclusive quectool snippet.
        # Keep any other lines that might have been added later.
        grep -v 'systemctl enable quectool' "$POST_BOOT" \
          | grep -v 'systemctl start quectool' \
          | grep -v 'Auto-enable QuecTool' \
          > "$tmp" || true
        # If nothing meaningful remains besides shebang/blank/sleep wrapper noise,
        # still keep the file rather than deleting it.
        mv -f "$tmp" "$POST_BOOT"
        chmod 0755 "$POST_BOOT" 2>/dev/null || true
        echo "    stripped legacy quectool lines from $POST_BOOT"
        return 0
    fi

    echo "    $POST_BOOT has no quectool markers; left untouched"
}

echo "==> removing CLI helper links"
rm -f /usrdata/root/bin/at /opt/bin/at /usrdata/bin/at 2>/dev/null || true
rm -f /usrdata/root/bin/qtrestart /opt/bin/qtrestart /usrdata/bin/qtrestart 2>/dev/null || true
rm -f /usrdata/root/bin/qtreboot /opt/bin/qtreboot /usrdata/bin/qtreboot 2>/dev/null || true
rm -f /usrdata/root/bin/qtstatus /opt/bin/qtstatus /usrdata/bin/qtstatus 2>/dev/null || true
rm -f /usrdata/root/bin/sendcommand /opt/bin/sendcommand /usrdata/bin/sendcommand 2>/dev/null || true
rm -f /usrdata/root/bin/quectool /opt/bin/quectool /usrdata/bin/quectool 2>/dev/null || true
# Legacy root-level helpers (pre-v1.6.33) + bin/
rm -f "$INSTALL_DIR/at" "$INSTALL_DIR/sendcommand" "$INSTALL_DIR/qtrestart" "$INSTALL_DIR/qtreboot" "$INSTALL_DIR/qtstatus" 2>/dev/null || true
rm -rf "$INSTALL_DIR/bin" 2>/dev/null || true

echo "==> stopping service"
systemctl stop quectool 2>/dev/null || true
systemctl disable quectool 2>/dev/null || true
# Direct-start path (install fallback when systemd returns 219/CGROUP).
if [ -f "$INSTALL_DIR/quectool.pid" ]; then
    kill "$(cat "$INSTALL_DIR/quectool.pid" 2>/dev/null)" 2>/dev/null || true
    rm -f "$INSTALL_DIR/quectool.pid"
fi
pkill -x quectool 2>/dev/null || true
sleep 1
# Detach RO bind links under jail/ (current model + any legacy leftovers).
# MUST run before purge — never rm -rf while host /bin|/usr are still linked.
umount_console_jail || true

echo "==> remounting / read-write"
remount rw

echo "==> removing systemd unit (both /lib and /etc paths)"
# Install may have chosen either location depending on /lib writability.
for unit in \
    /lib/systemd/system/quectool.service \
    /etc/systemd/system/quectool.service
do
    rm -f "$unit"
done
for wants in \
    /lib/systemd/system/multi-user.target.wants/quectool.service \
    /etc/systemd/system/multi-user.target.wants/quectool.service
do
    rm -f "$wants"
done

# Boot-persistence via /etc/init.d (RG50xQ OpenLinux)
rm -f /etc/init.d/quectool
rm -f /etc/rc5.d/S99quectool /etc/rcS.d/S99quectool 2>/dev/null

systemctl daemon-reload 2>/dev/null || true

echo "==> remounting / read-only"
remount ro

# post_boot lives under /usrdata — no root remount needed.
# Only strip if our block was ever written there.
if [ -f "$POST_BOOT" ]; then
    echo "==> cleaning quectool entries from $POST_BOOT (block only)"
    strip_post_boot_quectool
fi

# initscripts boot hook (RG50xQ-style). Owned by us entirely.
if [ -f /etc/initscripts/quectool ]; then
    echo "==> removing /etc/initscripts/quectool"
    /etc/initscripts/quectool stop 2>/dev/null || true
    rm -f /etc/initscripts/quectool /etc/initscripts/start_quectool
    rm -f /etc/init.d/quectool 2>/dev/null
    rm -rf /etc/rcS.d/S99quectool /etc/rc5.d/S99quectool 2>/dev/null
    rm -rf /etc/rc2.d/S99quectool /etc/rc3.d/S99quectool /etc/rc4.d/S99quectool 2>/dev/null
fi

if [ "$PURGE" = "1" ]; then
    echo "==> purging $INSTALL_DIR"
    # Umount again immediately before delete (belt and suspenders).
    if ! umount_console_jail; then
        echo "uninstall.sh: refusing full purge while jail mounts remain" >&2
        echo "    removed service units; left $INSTALL_DIR in place" >&2
        echo "    fix: umount -l $INSTALL_DIR/jail/* then re-run --purge" >&2
        exit 1
    fi
    rm -rf "$INSTALL_DIR"
else
    echo "==> leaving $INSTALL_DIR (config, certs, credentials, host_key preserved)."
    echo "    Pass --purge to remove."
fi

echo "QuecTool uninstalled."
