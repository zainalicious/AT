#!/bin/sh
# QuecTool on-modem uninstaller.
#
#   sh uninstall.sh           # stop + disable, leave /usrdata/quectool intact
#   sh uninstall.sh --purge   # also delete /usrdata/quectool entirely
#
# Run on the modem as root.

set -e

if [ "$(id -u)" != "0" ]; then
    echo "uninstall.sh: must run as root" >&2
    exit 1
fi

PURGE=0
if [ "$1" = "--purge" ]; then
    PURGE=1
fi

UNIT_DST=/lib/systemd/system/quectool.service
WANTS_LINK=/lib/systemd/system/multi-user.target.wants/quectool.service
INSTALL_DIR=/usrdata/quectool

remount() {
    mount -o "remount,$1" / 2>/dev/null || true
}

echo "==> stopping service"
systemctl stop quectool 2>/dev/null || true

# If AdGuard Home was installed via quectool, uninstall it first so DNS
# is restored and opkg packages are cleaned before we remove the binary
# that knows how to do it cleanly.
if [ -f /opt/bin/AdGuardHome ] || [ -f /opt/etc/init.d/S99adguardhome ]; then
    echo "==> uninstalling AdGuard Home (restoring dnsmasq to :53)"
    killall AdGuardHome 2>/dev/null || true
    # Restore dnsmasq.conf — strip port=54 if present
    if [ -f /etc/data/dnsmasq.conf ]; then
        grep -v '^port=54$' /etc/data/dnsmasq.conf > /etc/data/dnsmasq.conf.tmp \
            && mv /etc/data/dnsmasq.conf.tmp /etc/data/dnsmasq.conf || true
    fi
    # Restart dnsmasq so :53 comes back immediately
    killall -TERM dnsmasq 2>/dev/null || true
    sleep 2
    # Revive dnsmasq — same recipe as Go code (field-proven)
    mkdir -p /usrdata/quectool 2>/dev/null || true
    /usr/bin/dnsmasq --dhcp-leasefile=/usrdata/quectool/dnsmasq.leases &
    # Remove AGH package + data
    if [ -x /opt/bin/opkg ]; then
        /opt/bin/opkg remove adguardhome-go 2>/dev/null || true
    fi
    rm -rf /opt/etc/AdGuardHome /opt/etc/init.d/S99adguardhome
    rm -f /opt/var/log/AdGuardHome.log /opt/var/log/AdGuardHome.stderr.log \
          /opt/var/run/AdGuardHome.pid
    echo "==> AdGuard Home removed, dnsmasq restored"
fi

echo "==> remounting / read-write"
remount rw

echo "==> removing systemd unit"
rm -f "$WANTS_LINK"
rm -f "$UNIT_DST"
systemctl daemon-reload 2>/dev/null || true

echo "==> remounting / read-only"
remount ro

if [ "$PURGE" = "1" ]; then
    echo "==> purging $INSTALL_DIR"
    rm -rf "$INSTALL_DIR"
else
    echo "==> leaving $INSTALL_DIR (config + host_key preserved). Pass --purge to remove."
fi

echo "QuecTool uninstalled."
