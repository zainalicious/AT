#!/bin/sh
# QuecTool on-modem uninstaller.
#
#   sh uninstall.sh           # stop + disable, leave /usrdata/quectool intact
#   sh uninstall.sh --purge   # also delete /usrdata/quectool entirely
#
# Run on the modem as root.

set -e

if [ "$(id -u)" != "0" ]; then
    echo "uninstall.sh: must run as root" >&2
    exit 1
fi

PURGE=0
if [ "$1" = "--purge" ]; then
    PURGE=1
fi

UNIT_DST=/lib/systemd/system/quectool.service
WANTS_LINK=/lib/systemd/system/multi-user.target.wants/quectool.service
INSTALL_DIR=/usrdata/quectool

remount() {
    mount -o "remount,$1" / 2>/dev/null || true
}

echo "==> stopping service"
systemctl stop quectool 2>/dev/null || true

# If AdGuard Home is present, remove binary + all residue.
# dnsmasq restore is handled by quectool's Uninstall() via the API —
# call it here only if the binary exists (shell fallback when quectool gone).
if [ -f /opt/bin/AdGuardHome ] || [ -f /opt/etc/init.d/S99adguardhome ]; then
    echo "==> removing AdGuard Home"
    killall AdGuardHome 2>/dev/null || true
    # Restore dnsmasq.conf — strip our managed lines if quectool can't.
    if [ -f /etc/data/dnsmasq.conf ]; then
        grep -v -e '^no-resolv$' -e '^server=127\.0\.0\.1$' \
            /etc/data/dnsmasq.conf > /etc/data/dnsmasq.conf.tmp \
            && mv /etc/data/dnsmasq.conf.tmp /etc/data/dnsmasq.conf || true
    fi
    # Remove binary + temp/partial files.
    rm -f /opt/bin/AdGuardHome /opt/bin/AdGuardHome.tmp /opt/bin/AdGuardHome.new
    # Remove init script + workdir + logs + pid.
    rm -f /opt/etc/init.d/S99adguardhome
    rm -rf /opt/etc/AdGuardHome
    rm -f /opt/var/log/AdGuardHome.log /opt/var/log/AdGuardHome.stderr.log \
          /opt/var/run/AdGuardHome.pid
    echo "==> AdGuard Home removed"
fi

echo "==> remounting / read-write"
remount rw

echo "==> removing systemd unit"
rm -f "$WANTS_LINK"
rm -f "$UNIT_DST"
systemctl daemon-reload 2>/dev/null || true

echo "==> remounting / read-only"
remount ro

if [ "$PURGE" = "1" ]; then
    echo "==> purging $INSTALL_DIR"
    rm -rf "$INSTALL_DIR"
else
    echo "==> leaving $INSTALL_DIR (config + host_key preserved). Pass --purge to remove."
fi

echo "QuecTool uninstalled."

# Same reasoning as install.sh: quectool never restarts QCMAP's
# dnsmasq (by design — see adguard.restartDnsmasq doc comment), so
# dnsmasq.conf's reverted no-resolv/server=127.0.0.1 lines only take
# effect once QCMAP/firmware next restarts dnsmasq on its own. Reboot
# to make that happen immediately instead of DNS silently staying
# routed at AGH (now removed) until the next unrelated dnsmasq
# restart.
echo ""
echo "==> rebooting modem so QCMAP picks up the dnsmasq config revert"
sleep 3
reboot
